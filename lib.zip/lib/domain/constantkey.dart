class SharedPrefKey {
  static const String isLoggedIn = 'isLoggedIn';
}
